from project.caretaker import Caretaker
from project.cheetah import Cheetah
from project.keeper import Keeper
from project.lion import Lion
from project.tiger import Tiger
from project.vet import Vet
from project.zoo import Zoo

zoo = Zoo("Zoo", 1000, 10, 20)
print(zoo.add_animal(Cheetah("Sasha", "female", 20), 200))
print(zoo.add_animal(Tiger("Pen", "female", 10), 100))
print(zoo.add_animal(Lion("Gigi", "female", 4), 300))
print(zoo.animals_status())

print(zoo.hire_worker(Vet("Stoicho K", 30, 3000)))
print(zoo.hire_worker(Vet("Petq", 29, 3400)))
print(zoo.hire_worker(Caretaker("Koina", 25, 2000)))
print(zoo.hire_worker(Keeper("Bobi", 49, 1000)))
print(zoo.workers_status())
