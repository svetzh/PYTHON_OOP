from project.dog import Dog

obj = Dog()
print(f"{obj.eat()}\n{obj.bark()}")
