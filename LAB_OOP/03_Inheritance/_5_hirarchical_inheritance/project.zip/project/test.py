from project.animal import Animal
from project.cat import Cat
from project.dog import Dog


jivotno = Animal()
jivotno1 = Cat()
jivotno2 = Dog()
print(jivotno.eat())
print(jivotno1.eat())
print(jivotno2.eat())
print(jivotno2.bark())
print(jivotno1.meow())
